# Project 4: Around The U.S.

Visão geral

Figma
Link do projeto

_Este é um projeto que mostra o perfil de um usuário e cidades dos EUA como numa rede social. O projeto foi desenvolvido utilizando JS, HTML e CSS._

**Figma**

* [Link para o projeto no Figma](https://www.figma.com/file/SurN1jaeEQIhuZEDMhmWWf/Sprint-4-Around-The-U.S.-desktop-mobile?node-id=0%3A1)


**Link do projeto:** https://diego-galvao.github.io/web_project_4/

